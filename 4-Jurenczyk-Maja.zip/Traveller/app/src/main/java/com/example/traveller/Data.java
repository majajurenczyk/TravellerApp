package com.example.traveller;

public class Data {
    public static TourItem[] getItems() {
        return items;
    }

    private static TourItem [] items = {
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h1, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h2, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h3, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h4, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h5, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h6, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h7, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h8, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h9, 500, "11/03/2020", "15/03/2020"),
            new TourItem("Cypr / Paphos", "Gladiola", "Kraków",
                    4, R.drawable.h10, 500, "11/03/2020", "15/03/2020")
    };
}
